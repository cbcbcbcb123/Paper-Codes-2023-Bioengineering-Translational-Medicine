clear
clc

% R1: FAKina->FAKa
% R2: FAKa->FAKina
% R3: FAKa->Scl
% R4: Scl->null
% R5: MGF->Scl
% R6: MGF->null

F_Arry = zeros(100,1);

for j = 1:20
    %======
    % Parameters
    t = 0; % Simulation time
    P = 120; % P = 0 kPa or 90 kPa or 120 kPa or 150 kPa;
    C_Scl = 100; % Molecular number of Scl := 0
    C_MGF = 100; % Molecular number of MGF := 0 or 100
    C_FAKina = 1000; % Molecular number of activated FAKa := 1000
    C_FAKa = 0; % Molecular number of inactivated FAKa := 1000
    K1 = 60; % Hill function coefficient
    K2 = 50; % Hill function coefficient
    
    Ncyc = 30000;
    m = 1;
    total = 0;
    TimeArry = zeros(Ncyc,1);
    C_R_Arry = zeros(Ncyc,1);
    C_M_Arry = zeros(Ncyc,1);
    C_FAK_Arry = zeros(Ncyc,1);
    
    for i = 1:Ncyc
        %======
        % Rates of reactions
        r1f = 0.8 * P^5 / (P^5 + K1^5) * (exp(-t/5)) + 0.1 * C_MGF / (C_MGF + K2) + 0.01;
        r1r = 0.1;
        r2f = 0.1;
        r2r = 0.3;
        r3f = 0.1;
        r4f = 0.1;
        %======
        % Caculate reaction time
        Tlink_R1 = -log(rand) / (r1f * C_FAKina);
        Tlink_R2 = -log(rand) / (r1r * C_FAKa);
        Tlink_R3 = -log(rand) / (r2f * C_FAKa);
        Tlink_R4 = -log(rand) / (r2r * C_Scl);
        Tlink_R5 = -log(rand) / (r3f * C_MGF);
        Tlink_R6 = -log(rand) / (r4f * C_MGF);
        %======
        % Min time
        t1 = min(Tlink_R1,Tlink_R2);
        t2 = min(Tlink_R3,Tlink_R4);
        t3 = min(Tlink_R5,Tlink_R6);
        t4 = min(t1,t2);
        t5 = min(t3,t4);
        tmin = t5;
        %======
        % Go on
        t = t + tmin;
        %======
        % Reaction happen
        if tmin==Tlink_R1
            C_FAKina = C_FAKina - 1;
            C_FAKa = C_FAKa + 1;
        elseif tmin==Tlink_R2
            C_FAKina = C_FAKina + 1;
            C_FAKa = C_FAKa - 1;
        elseif tmin==Tlink_R3
            C_Scl = C_Scl + 1;
        elseif tmin==Tlink_R4
            C_Scl = C_Scl - 1;
        elseif tmin==Tlink_R5
            C_Scl = C_Scl + 1;
        elseif tmin==Tlink_R6
            C_MGF = C_MGF - 1;
        end
        %======
        TimeArry(i,1) = t;
        C_R_Arry(i,1) = C_Scl;
        C_M_Arry(i,1) = C_MGF;
        C_FAK_Arry(i,1) = C_FAKa;
        
        if t>12 && t<=24 % Mean value of Scl between 12 to 24 hours
            m = m + 1;
            total = total + C_Scl;
        end
        means = total / m;
    end
    
    F_Arry(j,1) = means;
end

% figure (1)
% plot(TimeArry,C_R_Arry)
% hold on
% axis([0,100,0,300]);
% set(gcf,'unit','centimeters','position',[10,5,12,8])
% xlabel('Time (h)');
% ylabel('The molecular number of Scleraxis');

% save
% set(gcf,'color','white');
% A=getframe(gcf);
% imwrite(A.cdata,'Fig1.png')
% saveas(gcf,'Fig1.fig');

F_Arry